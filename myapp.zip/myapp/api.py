from flask import make_response, Flask
from flask_restful import Resource, Api, fields, marshal_with, reqparse
from flask_sqlalchemy import SQLAlchemy
from werkzeug.exceptions import HTTPException
from flask_cors import CORS
import json
import os



current_dir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///"+os.path.join(current_dir,"mydata.sqlite3")
db = SQLAlchemy()
db.init_app(app)
app.app_context().push()
api = Api(app)
CORS(app)



class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True,autoincrement = True)
    name = db.Column(db.String(100), nullable=False)
    max_stock  = db.Column(db.Integer, nullable = False)
    show_relation=db.relationship("Product",backref="category_relation", secondary="assosciation") 

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True,autoincrement = True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(300), nullable = False)
    tags = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable = False)
    manufacturer = db.Column(db.String(150), nullable=False)
    stock = db.Column(db.Integer,nullable = False)
    category_id=db.Column(db.Integer, db.ForeignKey("category.id"), nullable=False)

class Assosciation(db.Model):
    roduct_id = db.Column(db.Integer, db.ForeignKey("product.id"),primary_key = True, nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("category.id"),primary_key = True,nullable = False)


class NotFoundError(HTTPException):
    def __init__(self, status_code, message=''):
        self.response = make_response(message, status_code)

class NotGivenErrors(HTTPException):
    def __init__(self, status_code, error_code, error_message):
        message = {"error_code": error_code, "error_message": error_message}
        self.response = make_response(json.dumps(message), status_code)


category_fields = {
    "id":fields.Integer,
    "name":fields.String,
    "max_stock":fields.Integer
}

product_fields = {
    "id":fields.Integer,
    "name":fields.String,
    "description":fields.String,
    "tags":fields.String,
    "price":fields.Float,
    "manufacturer":fields.String,
    "stock":fields.Integer,
    "category_id":fields.Integer
}

create_user_parser = reqparse.RequestParser()
create_user_parser.add_argument('name')
create_user_parser.add_argument('max_stock')

create_user_parse = reqparse.RequestParser()
create_user_parse.add_argument('name')
create_user_parse.add_argument('description')
create_user_parse.add_argument('tags')
create_user_parse.add_argument('price')
create_user_parse.add_argument('manufacturer')
create_user_parse.add_argument('stock')
create_user_parse.add_argument('category_id')

update_user_parser = reqparse.RequestParser()
update_user_parser.add_argument('name')
update_user_parser.add_argument('max_stock')

update_user_parse = reqparse.RequestParser()
update_user_parse.add_argument('name')
create_user_parse.add_argument('description')
update_user_parse.add_argument('tags')
update_user_parse.add_argument('price')
update_user_parse.add_argument('manufacturer')
update_user_parse.add_argument('stock')
update_user_parse.add_argument('category_id')


class CategoryApi(Resource):
    
    @marshal_with(category_fields)
    def get(self,id):
        category = Category.query.filter_by(id = id).first()
        if category is None:
            return NotFoundError(status_code=404)
        else:
            return category
    
    @marshal_with(category_fields)
    def post(self):
        args = create_user_parser.parse_args()
        name = args.get("name",None)
        max_stock = args.get("capacity",None)
        if name is None:
            return NotGivenErrors(status_code=400, error_code="name", error_message="Name is required")
        if max_stock is None:
            return NotGivenErrors(status_code=400, error_code="max_stock", error_message="Total stock  is required")
        Cat = Category.query.filter_by(name = name).first()
        if Cat is None:
            cat = Category(name = name, max_stock = max_stock)
            db.session.add(cat)
            db.session.commit()
            return cat,201
        else:
            return NotFoundError(status_code=409,message="category aldready exists")
    
    def delete(self,id):
        C = Category.query.filter_by(id = id).first()
        if C is not None:
            Category.query.filter_by(id = id).delete()
            db.session.commit()
            Assosciation.query.filter_by(category_id = id).delete()
            db.session.commit()
            return "deleted category",201
        return NotFoundError(status_code=404)
    
    @marshal_with(category_fields)
    def put(self,id):
        args = update_user_parser.parse_args()
        name = args.get("name")
        max_stock = args.get("max_stock")
        if name is None:
            return NotGivenErrors(status_code=400, error_code="name", error_message="Name is required")
        if max_stock is None:
            return NotGivenErrors(status_code=400, error_code="max_stock", error_message="Total stokc is required")
        
        cat = Category.query.filter_by(id = id).first()
        if cat is None:
            return NotFoundError(status_code=404)
        Category.query.filter(Category.id==id).update({'name':name,'max_stock':max_stock})
        db.session.commit()
        return cat



class ProductApi(Resource):
    
    @marshal_with(product_fields)
    def get(self,id):
        product = Product.query.filter_by(id = id).first()
        if product is None:
            return NotFoundError(status_code=404)
        else:
            return product
    
    @marshal_with(product_fields)
    def post(self):
        args = create_user_parse.parse_args()
        name = args.get("name",None)
        description = args.get("description", None)
        tags = args.get("tags",None)
        price = args.get("price",None)
        manufacturer = args.get("manufacturer",None)
        stock = args.get("stock",None)
        category_id = args.get("category_id",None)
        if name is None:
            return NotGivenErrors(status_code=400, error_code="name", error_message="Name is required")
        if description is None:
            return NotGivenErrors(status_code=400, error_code="description", error_message="description is required")
        if tags is None:
            return NotGivenErrors(status_code=400, error_code="tags", error_message="tags is required")
        if price is None:
            return NotGivenErrors(status_code=400, error_code="price", error_message="price is required")
        if manufacturer is None:
            return NotGivenErrors(status_code=400, error_code="manufacturer", error_message="manufacturer is required")
        if stock is None:
            return NotGivenErrors(status_code=400, error_code="stock", error_message="stock is required")
        if category_id is None:
            return NotGivenErrors(status_code=400, error_code="c_id", error_message="c_id is required")
        Product_a = Product.query.filter_by(name = name,venue_id = category_id ).first()
        if Product_a is None:
            s_1 = Product(name = name,description=description, tags = tags, price = price, manufacturer = manufacturer, stock = stock,category_id = category_id)
            db.session.add(s_1)
            db.session.commit()
            return s_1,201
        else:
            return NotFoundError(status_code=409,message="product aldready exists")
    
    def delete(self,id):
        V = Product.query.filter_by(id = id).first()
        if V is not None:
            Product.query.filter_by(id = id).delete()
            db.session.commit()
            Assosciation.query.filter_by(product_id = id).delete()
            db.session.commit()
            return "deleted product",201
        return NotFoundError(status_code=404)
    
    @marshal_with(product_fields)
    def put(self,id):
        args = create_user_parse.parse_args()
        name = args.get("name",None)
        description = args.get("description", None)
        tags = args.get("tags",None)
        price = args.get("price",None)
        manufacturer = args.get("manufacturer",None)
        stock = args.get("stock",None)
        categroy_id = args.get("category_id",None)
        if name is None:
            return NotGivenErrors(status_code=400, error_code="name", error_message="Name is required")
        if description is None:
            return NotGivenErrors(status_code=400, erro_code="description", error_message="Description is required")
        if tags is None:
            return NotGivenErrors(status_code=400, error_code="tags", error_message="tags is required")
        if price is None:
            return NotGivenErrors(status_code=400, error_code="price", error_message="price is required")
        if manufacturer is None:
            return NotGivenErrors(status_code=400, error_code="manufacturer", error_message="manufacturer is required")
        if stock is None:
            return NotGivenErrors(status_code=400, error_code="stock", error_message="stock is required")
        if categroy_id is None:
            return NotGivenErrors(status_code=400, error_code="c_id", error_message="c_id is required")
        so = Category.query.filter_by(id = id).first()
        if so is None:
            return NotFoundError(status_code=404)
        Product.query.filter(Product.id==id).update({'name':name, 'description':description, 'tags':tags,'price':price,'manufacturer':manufacturer,'stock':stock,'category_id':categroy_id})
        db.session.commit()
        return so

api.add_resource(CategoryApi, "/api/category/<int:id>", "/api/category")
api.add_resource(ProductApi, "/api/product/<int:id>", "/api/product")

if __name__ == "__main__":
    app.run(debug = True)